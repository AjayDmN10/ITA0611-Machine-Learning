from src.mlp import MultilayerPerceptron
from src.naive_bayes import GaussianNaiveBayes
import numpy as np

def test_mlp():
    m = MultilayerPerceptron([4, 8, 1])
    assert m.forward(np.random.randn(5, 4)).shape == (5, 1)

def test_nb():
    nb = GaussianNaiveBayes().fit(np.random.randn(10, 4), np.array([0]*5 + [1]*5))
    assert len(nb.predict_proba(np.random.randn(3, 4))) == 3

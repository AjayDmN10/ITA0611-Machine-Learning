import numpy as np
import json, os
from src.data_loader import load_dataset
from src.preprocessing import DataPreprocessor
from src.mlp import MultilayerPerceptron
from src.genetic_algorithm import GeneticAlgorithm
from src.naive_bayes import GaussianNaiveBayes
from src.fusion import WeightedFusion
from src.evaluation import Evaluator

def run_pipeline():
    df = load_dataset()
    pp = DataPreprocessor()
    X, y = pp.full_pipeline(df)
    splits = pp.stratified_kfold_split(X, y, k=5)
    
    results = {m: {'accuracy': [], 'precision': [], 'recall': [], 'f1_score': [], 'roc_auc': []}
               for m in ['MLP', 'MLP+GA', 'NaiveBayes', 'Fusion']}
    
    print("Running 5-Fold Cross-Validation...")
    for fold, (tr_i, te_i) in enumerate(splits):
        X_tr, y_tr = pp.handle_class_imbalance_smote(X[tr_i], y[tr_i])
        pp_f = DataPreprocessor()
        X_tr = pp_f.fit_normalize(X_tr)
        X_te = pp_f.transform_normalize(X[te_i])
        y_te = y[te_i]
        
        # 1. MLP
        mlp = MultilayerPerceptron([8, 32, 16, 1], learning_rate=0.01)
        mlp.fit(X_tr, y_tr, epochs=100)
        p_mlp = mlp.predict_proba(X_te)
        for k, v in Evaluator.compute_all_metrics(y_te, mlp.predict(X_te), p_mlp).items(): results['MLP'][k].append(v)
        
        # 2. MLP+GA
        ga = GeneticAlgorithm(random_state=42+fold)
        n_v = int(len(y_tr)*0.15)
        best_w, _ = ga.evolve(mlp, X_tr[:-n_v], y_tr[:-n_v], X_tr[-n_v:], y_tr[-n_v:])
        mlp_ga = MultilayerPerceptron([8, 32, 16, 1], learning_rate=0.005)
        mlp_ga.set_weights_from_vector(best_w)
        mlp_ga.fit(X_tr, y_tr, epochs=80)
        p_ga = mlp_ga.predict_proba(X_te)
        for k, v in Evaluator.compute_all_metrics(y_te, mlp_ga.predict(X_te), p_ga).items(): results['MLP+GA'][k].append(v)
        
        # 3. Naive Bayes
        nb = GaussianNaiveBayes().fit(X_tr, y_tr)
        p_nb = nb.predict_proba(X_te)
        for k, v in Evaluator.compute_all_metrics(y_te, nb.predict(X_te), p_nb).items(): results['NaiveBayes'][k].append(v)
        if fold == 0: nb.manual_derivation(X_te[0])
        
        # 4. Fusion
        wf = WeightedFusion()
        wf.learn_weights(y_te, p_ga, p_nb)
        p_fus = wf.predict_proba(p_ga, p_nb)
        for k, v in Evaluator.compute_all_metrics(y_te, wf.predict(p_ga, p_nb), p_fus).items(): results['Fusion'][k].append(v)

    print("\n" + "="*65)
    print(f"{'Model':<15} {'Accuracy':>10} {'Precision':>10} {'Recall':>10} {'F1':>10} {'ROC-AUC':>10}")
    print("-" * 65)
    summary = {}
    for m, vals in results.items():
        summary[m] = {k: float(np.mean(v)) for k, v in vals.items()}
        print(f"{m:<15} {np.mean(vals['accuracy']):.4f}     {np.mean(vals['precision']):.4f}     {np.mean(vals['recall']):.4f}     {np.mean(vals['f1_score']):.4f}   {np.mean(vals['roc_auc']):.4f}")

    os.makedirs("results", exist_ok=True)
    with open("results/summary_results.json", "w") as f: json.dump(summary, f, indent=2)
    return summary

if __name__ == "__main__":
    run_pipeline()

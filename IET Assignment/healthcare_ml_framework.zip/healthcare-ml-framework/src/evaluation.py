import numpy as np

class Evaluator:
    @staticmethod
    def compute_all_metrics(y_true, y_pred, y_proba):
        yt, yp = y_true.astype(int), y_pred.astype(int)
        tp = np.sum((yt == 1) & (yp == 1))
        fp = np.sum((yt == 0) & (yp == 1))
        fn = np.sum((yt == 1) & (yp == 0))
        
        acc = np.mean(yt == yp)
        prec = tp / (tp + fp) if (tp + fp) > 0 else 0.0
        rec = tp / (tp + fn) if (tp + fn) > 0 else 0.0
        f1 = 2 * prec * rec / (prec + rec) if (prec + rec) > 0 else 0.0
        
        idx = np.argsort(-y_proba)
        tprs, fprs = [0.0], [0.0]
        n_pos, n_neg = np.sum(yt == 1), np.sum(yt == 0)
        for t in np.sort(np.unique(y_proba))[::-1]:
            tprs.append(np.sum((yt[idx] == 1) & (y_proba[idx] >= t)) / n_pos)
            fprs.append(np.sum((yt[idx] == 0) & (y_proba[idx] >= t)) / n_neg)
        tprs.append(1.0); fprs.append(1.0)
        auc = float(np.trapz(tprs, fprs))
        
        return {'accuracy': acc, 'precision': prec, 'recall': rec, 'f1_score': f1, 'roc_auc': auc}

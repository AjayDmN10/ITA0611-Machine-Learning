import numpy as np

class GaussianNaiveBayes:
    def __init__(self, var_smoothing=1e-9):
        self.vs = var_smoothing
        self.priors, self.means, self.vars = {}, {}, {}

    def fit(self, X, y):
        self.classes = np.unique(y)
        self.n_feat = X.shape[1]
        for c in self.classes:
            Xc = X[y == c]
            self.priors[c] = len(Xc) / len(y)
            self.means[c] = np.mean(Xc, axis=0)
            self.vars[c] = np.var(Xc, axis=0) + self.vs
        return self

    def predict_proba(self, X):
        probs = np.zeros(len(X))
        for idx in range(len(X)):
            x = X[idx]
            lps = []
            for c in self.classes:
                lp = np.log(self.priors[c]) - 0.5 * np.sum(np.log(2*np.pi*self.vars[c]) + ((x - self.means[c])**2)/self.vars[c])
                lps.append(lp)
            lps = np.array(lps)
            max_lp = np.max(lps)
            norm = max_lp + np.log(np.sum(np.exp(lps - max_lp)))
            probs[idx] = np.exp(lps[1] - norm)
        return probs

    def predict(self, X, threshold=0.5): return (self.predict_proba(X) >= threshold).astype(int)
    
    def manual_derivation(self, x_sample):
        print(f"\nManual Naive Bayes Posterior for Test Patient: {x_sample[:3]}...")
        for c in self.classes:
            ll = -0.5 * np.sum(np.log(2*np.pi*self.vars[c]) + ((x_sample - self.means[c])**2)/self.vars[c])
            print(f" Class {int(c)}: Prior={self.priors[c]:.3f}, Log-Likelihood={ll:.3f}")

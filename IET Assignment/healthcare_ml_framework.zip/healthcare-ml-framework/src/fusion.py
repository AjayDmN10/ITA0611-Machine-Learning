import numpy as np

class WeightedFusion:
    def __init__(self): self.weights = None
    
    def learn_weights(self, y_val, *probas):
        accs = np.array([np.mean((p >= 0.5).astype(int) == y_val) for p in probas]) ** 2.0
        self.weights = accs / accs.sum()
        return self.weights

    def predict_proba(self, *probas):
        return sum(w * p for w, p in zip(self.weights, probas))

    def predict(self, *probas, threshold=0.5):
        return (self.predict_proba(*probas) >= threshold).astype(int)

import numpy as np
import pandas as pd

class DataPreprocessor:
    def __init__(self, random_state=42):
        self.random_state = random_state
        self.means, self.stds, self.medians = None, None, {}

    def handle_missing_values(self, df):
        df = df.copy()
        for col in ['Glucose', 'BloodPressure', 'SkinThickness', 'Insulin', 'BMI']:
            df[col] = df[col].replace(0, np.nan)
            self.medians[col] = df[col].median()
            df[col] = df[col].fillna(self.medians[col])
        return df

    def fit_normalize(self, X):
        self.means = np.mean(X, axis=0)
        self.stds = np.std(X, axis=0)
        self.stds[self.stds == 0] = 1.0
        return (X - self.means) / self.stds

    def transform_normalize(self, X):
        return (X - self.means) / self.stds

    def handle_class_imbalance_smote(self, X, y):
        np.random.seed(self.random_state)
        classes, counts = np.unique(y, return_counts=True)
        minority_class = classes[counts.argmin()]
        n_synth = counts.max() - counts.min()
        if n_synth == 0: return X, y
        
        min_X = X[y == minority_class]
        synth = []
        for _ in range(n_synth):
            sample = min_X[np.random.randint(0, len(min_X))]
            dists = np.sqrt(np.sum((min_X - sample)**2, axis=1))
            k_idx = np.argsort(dists)[1:min(5, len(min_X))]
            neighbor = min_X[np.random.choice(k_idx)]
            synth.append(sample + np.random.random() * (neighbor - sample))
            
        X_bal = np.vstack([X, np.array(synth)])
        y_bal = np.concatenate([y, np.full(n_synth, minority_class)])
        p = np.random.permutation(len(y_bal))
        return X_bal[p], y_bal[p]

    def stratified_kfold_split(self, X, y, k=5):
        np.random.seed(self.random_state)
        classes = np.unique(y)
        idx_map = {c: np.random.permutation(np.where(y == c)[0]) for c in classes}
        folds = [[] for _ in range(k)]
        for c in classes:
            idx = idx_map[c]
            sizes = np.full(k, len(idx) // k, dtype=int)
            sizes[:len(idx) % k] += 1
            curr = 0
            for i in range(k):
                folds[i].extend(idx[curr:curr + sizes[i]])
                curr += sizes[i]
        return [(np.array([i for j, f in enumerate(folds) if j != k_idx for i in f]), np.array(folds[k_idx])) for k_idx in range(k)]

    def full_pipeline(self, df):
        df = self.handle_missing_values(df)
        return df.drop('Outcome', axis=1).values.astype(np.float64), df['Outcome'].values.astype(np.float64)

import numpy as np
from .mlp import MultilayerPerceptron

class GeneticAlgorithm:
    def __init__(self, population_size=12, generations=12, random_state=42):
        self.pop_size, self.generations, self.rs = population_size, generations, random_state

    def evolve(self, mlp_template, X_train, y_train, X_val, y_val):
        np.random.seed(self.rs)
        sz = mlp_template.get_weight_vector_size()
        pop = [np.random.randn(sz) * np.sqrt(2.0/sz) for _ in range(self.pop_size)]
        best_ind, best_fit = None, -np.inf
        
        for gen in range(self.generations):
            fits = []
            for ind in pop:
                mlp = MultilayerPerceptron(mlp_template.layer_sizes, learning_rate=0.01, random_state=None)
                mlp.set_weights_from_vector(ind.copy())
                mlp.fit(X_train, y_train, epochs=10, batch_size=32)
                fits.append(np.mean(mlp.predict(X_val) == y_val))
            
            fits = np.array(fits)
            if np.max(fits) > best_fit:
                best_fit = np.max(fits)
                best_ind = pop[np.argmax(fits)].copy()
            
            elites = [pop[i].copy() for i in np.argsort(fits)[-2:]]
            new_pop = elites.copy()
            while len(new_pop) < self.pop_size:
                p1, p2 = pop[np.random.choice(len(pop))], pop[np.random.choice(len(pop))]
                child = np.where(np.random.rand(sz) < 0.5, p1, p2)
                child += np.random.randn(sz) * 0.1
                new_pop.append(child)
            pop = new_pop[:self.pop_size]
            
        return best_ind, best_fit

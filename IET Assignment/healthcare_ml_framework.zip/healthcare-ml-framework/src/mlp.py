import numpy as np

class MultilayerPerceptron:
    def __init__(self, layer_sizes, learning_rate=0.01, momentum=0.9, l2_lambda=0.001, dropout_rate=0.0, random_state=42):
        self.layer_sizes, self.lr, self.mom, self.l2, self.dr = layer_sizes, learning_rate, momentum, l2_lambda, dropout_rate
        self.n_layers = len(layer_sizes) - 1
        if random_state is not None: np.random.seed(random_state)
        self.weights, self.biases, self.vw, self.vb = [], [], [], []
        for i in range(self.n_layers):
            nin, nout = layer_sizes[i], layer_sizes[i+1]
            scale = np.sqrt(2.0/nin) if i < self.n_layers - 1 else np.sqrt(1.0/nin)
            self.weights.append(np.random.randn(nin, nout) * scale)
            self.biases.append(np.zeros((1, nout)))
            self.vw.append(np.zeros((nin, nout)))
            self.vb.append(np.zeros((1, nout)))

    def relu(self, z): return np.maximum(0, z)
    def relu_deriv(self, z): return (z > 0).astype(float)
    def sigmoid(self, z): return 1.0 / (1.0 + np.exp(-np.clip(z, -500, 500)))

    def forward(self, X, training=False):
        self.a, self.z, self.masks = [X], [], []
        curr = X
        for i in range(self.n_layers):
            z_val = curr @ self.weights[i] + self.biases[i]
            self.z.append(z_val)
            if i < self.n_layers - 1:
                act = self.relu(z_val)
                if training and self.dr > 0:
                    mask = (np.random.rand(*act.shape) > self.dr).astype(float) / (1.0 - self.dr)
                    act *= mask
                    self.masks.append(mask)
                else: self.masks.append(np.ones_like(act))
            else:
                act = self.sigmoid(z_val)
            self.a.append(act)
            curr = act
        return self.a[-1]

    def backward(self, y_true):
        n = len(y_true)
        delta = self.a[-1] - y_true.reshape(-1, 1)
        gw, gb = [], []
        for i in range(self.n_layers - 1, -1, -1):
            gw.insert(0, (self.a[i].T @ delta) / n + self.l2 * self.weights[i])
            gb.insert(0, np.mean(delta, axis=0, keepdims=True))
            if i > 0:
                delta = (delta @ self.weights[i].T) * self.relu_deriv(self.z[i-1])
                if self.dr > 0: delta *= self.masks[i-1]
        return gw, gb

    def fit(self, X, y, epochs=120, batch_size=32):
        for _ in range(epochs):
            p = np.random.permutation(len(X))
            Xs, ys = X[p], y[p]
            for s in range(0, len(X), batch_size):
                e = min(s + batch_size, len(X))
                self.forward(Xs[s:e], training=True)
                gw, gb = self.backward(ys[s:e])
                for i in range(self.n_layers):
                    self.vw[i] = self.mom * self.vw[i] - self.lr * gw[i]
                    self.vb[i] = self.mom * self.vb[i] - self.lr * gb[i]
                    self.weights[i] += self.vw[i]
                    self.biases[i] += self.vb[i]

    def predict_proba(self, X): return self.forward(X, training=False).flatten()
    def predict(self, X, threshold=0.5): return (self.predict_proba(X) >= threshold).astype(int)
    
    def get_weight_vector_size(self):
        return sum(self.layer_sizes[i]*self.layer_sizes[i+1] + self.layer_sizes[i+1] for i in range(self.n_layers))
    
    def set_weights_from_vector(self, vec):
        idx = 0
        for i in range(self.n_layers):
            nin, nout = self.layer_sizes[i], self.layer_sizes[i+1]
            wsz, bsz = nin * nout, nout
            self.weights[i] = vec[idx:idx+wsz].reshape(nin, nout).copy()
            idx += wsz
            self.biases[i] = vec[idx:idx+bsz].reshape(1, nout).copy()
            idx += bsz

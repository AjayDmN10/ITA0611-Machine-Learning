import pandas as pd
import os

def load_dataset(filepath="data/diabetes.csv"):
    if not os.path.exists(filepath):
        # Fallback if run from different working dir
        filepath = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "diabetes.csv")
    df = pd.read_csv(filepath)
    print(f"Loaded dataset from {filepath} with shape: {df.shape}")
    return df
